﻿using System;
using System.Threading.Tasks;
using System.Windows;
using Ping9719.MindeoScanner;
using ZXing;
namespace Entry_QR
{
    public partial class MainWindow : Window
    {
        private MindeoScanner scanner;
        private BarcodeReader reader;

        private Usual usual = new Usual();
        private Technical technical = new Technical();


        public MainWindow()
        {
            InitializeComponent();
            scanner = new MindeoScanner();
            reader = new BarcodeReader();

            var barcodeBitmap = scanner.Scan();
            var result = reader.Decode(barcodeBitmap);
            if (result != null)
            {
                string[] separator = result.Text.Split(';');
                if (separator.Length == 2)
                {
                    string login = separator[0];
                    string password = separator[1];

                    if (login == "user" && password == "password")
                    {
                        text.Text = "Добро пожаловать, пользователь!";
                        usual.Show();
                    }
                    else if (login == "tech" && password == "password")
                    {
                        text.Text = "Добро пожаловать, техник!";
                        technical.Show();
                    }
                    else
                    {
                        text.Text = "Такого пользователя не существует.";
                    }
                }
            }
        }
    }
}